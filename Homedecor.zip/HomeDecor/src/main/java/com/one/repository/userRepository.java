package com.one.repository;

public interface userRepository {

}
