


package com.one.controller;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.one.entity.user;
import com.one.exception.ResourceNotFound;
import com.one.repository.userRepository;

import antlr.collections.List;



@RestController
@RequestMapping("/api/members")
public class usersController {

	
	@Autowired
	public userRepository userRepository;
	
	//get all members
	@GetMapping
	public List<user>getAllMembers(){
		return this.userRepository.findAll();
	}
		//get members by id
	@GetMapping("/{id}")
		public user getMembersById(@PathVariable (value = "id") long membersId) {
			return this.userRepository.findById(membersId)
					.orElseThrow(()->new ResourceNotFound("user not found with id:" + membersId));
	}
	//create Members
	@PostMapping
	public user createUser(@RequestBody user User) {
		
		return this.userRepository.save(User);
	}
			//update Members
	@PutMapping("/{id}")
	public user updateMembers(@RequestBody user members,@PathVariable("id") long membersId) {
		user existingMembers =  this.userRepository.findById(membersId)
				.orElseThrow(()->new ResourceNotFound("user not found with id:" + membersId));
		existingMembers.setFirstName(members.getFirstName());
		existingMembers.setLastName(members.getLastName());
		existingMembers.setEmail(members.getEmail());
		
		return this.userRepository.save(existingMembers);
	}
	//delete Members by id
	@DeleteMapping("/{id}")
	public ResponseEntity<user> deleteMembers(@PathVariable ("id")long membersId){
		user existingMembers =  this.userRepository.findById(membersId)
				.orElseThrow(()->new ResourceNotFound("user not found with id:" + membersId));
		this.userRepository.delete(existingMembers);
		return ResponseEntity.ok().build();
		
		
	}

		}
		
	
	

