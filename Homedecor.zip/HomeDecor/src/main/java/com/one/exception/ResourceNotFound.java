package com.one.exception;

public class ResourceNotFound {

}
