package com.one.entity;

public class user {

}
